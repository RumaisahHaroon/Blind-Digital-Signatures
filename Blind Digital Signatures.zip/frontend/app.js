const BASE = "http://localhost:5000";

let blindedData = {};
let blindSignature = null;
let finalSignature = null;
let message = "";
function short(val) {
    return val.toString().slice(0, 50) + "...";
}

function log(msg) {
    document.getElementById("output").innerText += msg + "\n\n";
}

function clearLog() {
    document.getElementById("output").innerText = "";
}

// Enable next step
function enable(id) {
    document.getElementById(id).disabled = false;
}

// STEP 1
async function getKey() {
    clearLog();

    let res = await fetch(`${BASE}/public-key`);
    let data = await res.json();

    log("✔ Public Key Received");
    log("System ready to start blind signature protocol");

    enable("btnBlind");
}

// STEP 2
async function blindVote() {
    let candidate = document.getElementById("vote").value;
    message = "vote:" + candidate;

    let res = await fetch(`${BASE}/blind`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({message})
    });

    blindedData = await res.json();

    log("🔒 Vote Blinded");
    log("Original Message: " + message);
    log("Blinded Value: " + short(blindedData.blinded));
    log("NOTE: Server cannot see the original vote");

    enable("btnSign");
}

// STEP 3
async function signVote() {
    let res = await fetch(`${BASE}/sign`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            blinded_message: blindedData.blinded
        })
    });

    let data = await res.json();
    blindSignature = data.blind_signature;

    log("✍ Server Signed Blinded Message");
    log("Blind Signature: " + short(blindSignature));

    enable("btnUnblind");
}

// STEP 4
async function unblindVote() {
    let res = await fetch(`${BASE}/unblind`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            blind_signature: blindSignature,
            r: blindedData.r,
            hash: blindedData.hash
        })
    });

    let data = await res.json();
    finalSignature = data.signature;

    log("🔓 Signature Unblinded");
    log("Final Signature: " + short(finalSignature));

    enable("btnSubmit");
}

// STEP 5
async function submitVote() {
    let res = await fetch(`${BASE}/submit-vote`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            message,
            signature: finalSignature
        })
    });

    let data = await res.json();

    if (data.valid) {
        log("✅ Vote Successfully Submitted");
        log("Voted for: " + data.voted_for);
    } else {
        log("❌ Error: " + data.error);
    }
}

// RESULTS
async function getResults() {
    let res = await fetch(`${BASE}/results`);
    let data = await res.json();

    log("📊 Live Results:");
    log(JSON.stringify(data, null, 2));
}

// RESET
function resetAll() {
    blindedData = {};
    blindSignature = null;
    finalSignature = null;
    message = "";
    clearLog();

    document.getElementById("btnBlind").disabled = true;
    document.getElementById("btnSign").disabled = true;
    document.getElementById("btnUnblind").disabled = true;
    document.getElementById("btnSubmit").disabled = true;

    log("System Reset Complete");
}