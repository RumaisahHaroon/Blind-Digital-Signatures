"""
crypto.py — Chaum's RSA Blind Signature Scheme

Protocol Overview
-----------------
1. Voter (User) blinds their vote/message using a random blinding factor r:
       blinded = (m_hash * r^e) mod n
2. Authority (Signer) signs the blinded message without seeing the original:
       blind_sig = blinded^d mod n
3. Voter unblinds the signature using the stored blinding factor:
       signature = (blind_sig * r_inv) mod n
4. Anyone can verify the signature using the signer's public key:
       m_hash == signature^e mod n

Cryptographic Guarantees
------------------------
- Blindness  : Signer cannot link the signed message to the original blinded message.
- Unforgeability: Only the legitimate signer (private key holder) can produce valid sigs.
- Verifiability : Any party with the public key can verify signature authenticity.
"""

import hashlib
import secrets
import logging
from dataclasses import dataclass
from typing import Tuple

from Crypto.PublicKey import RSA
from Crypto.Util.number import inverse, bytes_to_long, long_to_bytes

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

@dataclass
class PublicKey:
    """RSA Public Key components."""
    e: int   # public exponent
    n: int   # modulus
    key_size: int  # bits

    def __repr__(self):
        return f"PublicKey(e={self.e}, n=<{self.key_size}-bit modulus>)"


@dataclass
class PrivateKey:
    """RSA Private Key components."""
    d: int   # private exponent
    n: int   # modulus
    p: int   # prime factor p
    q: int   # prime factor q
    key_size: int  # bits

    def __repr__(self):
        return f"PrivateKey(d=<hidden>, n=<{self.key_size}-bit modulus>)"


@dataclass
class BlindedMessage:
    """Holds the blinded message and the secret blinding factor."""
    blinded: int           # (H(m) * r^e) mod n  — sent to signer
    blinding_factor: int   # r  — kept secret by voter
    message_hash: int      # H(m) as integer — kept by voter for verification


@dataclass
class KeyPair:
    """RSA Key Pair."""
    public_key: PublicKey
    private_key: PrivateKey


# ---------------------------------------------------------------------------
# Core Functions
# ---------------------------------------------------------------------------

def generate_keys(key_size: int = 2048) -> KeyPair:
    """
    Generate an RSA key pair for the signing authority.

    The election authority runs this once. The public key is published
    to all voters. The private key is kept strictly secret by the authority.


    Security Note:
        e=65537 (Fermat F4) is the standard safe choice for the public exponent.
        PyCryptodome's key generation uses a CSPRNG internally.
    """
    if key_size < 1024:
        raise ValueError("Key size must be at least 1024 bits.")
    if key_size < 2048:
        logger.warning("Key size < 2048 bits is insecure. Use only for testing.")

    rsa_key = RSA.generate(key_size)

    pub = PublicKey(
        e=rsa_key.e,
        n=rsa_key.n,
        key_size=key_size
    )
    priv = PrivateKey(
        d=rsa_key.d,
        n=rsa_key.n,
        p=rsa_key.p,
        q=rsa_key.q,
        key_size=key_size
    )

    logger.info(f"Keys generated — {key_size}-bit RSA, e={rsa_key.e}")
    return KeyPair(public_key=pub, private_key=priv)


def _hash_message(message: bytes) -> int:
    """
    Hash a message using SHA-256 and return it as an integer.

    Internal helper. SHA-256 ensures fixed-size input to RSA regardless
    of vote/message length. Converts digest to a big integer for modular
    arithmetic.

    """
    digest = hashlib.sha256(message).digest()
    return bytes_to_long(digest)


def blind_message(message: bytes, public_key: PublicKey) -> BlindedMessage:
    """
    Voter-side: Blind a message before sending to the signing authority.

    Steps:
      1. Hash the message: m = H(message)
      2. Choose a random blinding factor r, where gcd(r, n) = 1
      3. Compute blinded = (m * r^e) mod n
      4. Return blinded (sent to signer) and r (kept secret)

    The signer receives only `blinded` and never sees the original message.
    This is the BLINDNESS property of the scheme.

    """
    n = public_key.n
    e = public_key.e

    # Hash the message to a fixed-size integer
    m_hash = _hash_message(message)

    # Ensure hash is reduced mod n 
    m_hash = m_hash % n

    # Generate a cryptographically random blinding factor r
    # r must be coprime to n
    # Since n = p*q, any random r in [2, n-2]
    while True:
        r = secrets.randbelow(n - 2) + 2  # r in [2, n-2]
        # Verify gcd(r, n) == 1 using Euclidean algorithm
        if _gcd(r, n) == 1:
            break

    # Compute blinded message: (m_hash * r^e) mod n
    r_e = pow(r, e, n)
    blinded = (m_hash * r_e) % n

    logger.debug("Message blinded successfully. Blinding factor generated.")
    return BlindedMessage(
        blinded=blinded,
        blinding_factor=r,
        message_hash=m_hash
    )


def sign_blinded(blinded_msg: int, private_key: PrivateKey) -> int:
    """
    Authority-side: Sign a blinded message using the private key.

    The authority computes:
        blind_signature = blinded_msg^d mod n

    CRITICAL: The signer only ever sees the blinded value, never the
    original message. This enforces voter anonymity — the authority
    cannot link a signature to a specific voter's choice.

    """
    if blinded_msg <= 0 or blinded_msg >= private_key.n:
        raise ValueError("Blinded message must be in range (0, n).")

    blind_sig = pow(blinded_msg, private_key.d, private_key.n)
    logger.debug("Blinded message signed by authority.")
    return blind_sig


def unblind_signature(blind_sig: int, blinded_message: BlindedMessage,
                       public_key: PublicKey) -> int:
    """
    Voter-side: Remove the blinding factor to recover the real signature.

    Computes:
        signature = blind_sig * r_inv mod n

    Where r_inv is the modular inverse of the blinding factor r.

    """
    n = public_key.n
    r = blinded_message.blinding_factor

    # Compute modular inverse of r
    r_inv = inverse(r, n)

    # Unblind: multiply by r_inv to cancel the blinding factor
    signature = (blind_sig * r_inv) % n

    logger.debug("Signature unblinded successfully.")
    return signature


def verify_signature(message: bytes, signature: int,
                      public_key: PublicKey) -> bool:
    """
    Verifier-side: Verify that a signature is valid for a given message.

    Computes:
        recovered = signature^e mod n
        expected  = H(message) mod n

    If recovered == expected, the signature is valid.

    This can be performed by ANY party holding the public key —
    election observers, auditors, or the voter themselves.

    """
    n = public_key.n
    e = public_key.e

    # Recover the message hash from the signature
    recovered_hash = pow(signature, e, n)

    # Hash the message independently
    expected_hash = _hash_message(message) % n

    is_valid = (recovered_hash == expected_hash)

    if is_valid:
        logger.info("Signature VALID — vote is authentic and verifiable.")
    else:
        logger.warning("Signature INVALID — possible tampering or wrong key.")

    return is_valid


# ---------------------------------------------------------------------------
# Utility / Helper Functions
# ---------------------------------------------------------------------------

def _gcd(a: int, b: int) -> int:
    """Euclidean GCD — used to verify blinding factor coprimality."""
    while b:
        a, b = b, a % b
    return a


def demonstrate_blindness(message: bytes, public_key: PublicKey,
                           private_key: PrivateKey) -> dict:
    """
    Demo that the signer cannot link a blinded message to the original.

    Runs the full protocol and shows the signer only sees the blinded value,
    which is computationally indistinguishable from random without knowing r.

    """
    blind_msg = blind_message(message, public_key)

    result = {
        "original_message": message.decode(errors="replace"),
        "message_hash": hex(blind_msg.message_hash),
        "blinded_value_seen_by_signer": hex(blind_msg.blinded),
        "blinding_factor_r": hex(blind_msg.blinding_factor),
        "signer_can_see_original": False,
        "signer_can_deduce_original": False,
    }

    blind_sig = sign_blinded(blind_msg.blinded, private_key)
    signature = unblind_signature(blind_sig, blind_msg, public_key)
    valid = verify_signature(message, signature, public_key)

    result["final_signature"] = hex(signature)
    result["verification_passes"] = valid

    return result


def export_public_key_pem(key_pair: KeyPair) -> str:
    """Export the public key in PEM format for sharing with other system modules."""
    rsa_key = RSA.construct((key_pair.public_key.n, key_pair.public_key.e))
    return rsa_key.export_key("PEM").decode()


def import_public_key_pem(pem_str: str) -> PublicKey:
    """Import a PEM-encoded public key (used by other team members' modules)."""
    rsa_key = RSA.import_key(pem_str.encode())
    return PublicKey(e=rsa_key.e, n=rsa_key.n, key_size=rsa_key.n.bit_length())