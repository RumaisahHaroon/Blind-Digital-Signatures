"""
app.py (Flask Backend for Blind Signature E-Voting System)
Member 2 (Amna)
"""

import sys
import os
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from crypto.crypto import (
    generate_keys,
    sign_blinded,
    verify_signature,
    export_public_key_pem,
)

# Logging 
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# App Setup 
app = Flask(__name__)
CORS(app)  # Allows frontend to call this server 

# Key Generation 
# Generated once at startup. Private key never leaves this file.
logger.info("Generating RSA keys...")
key_pair    = generate_keys()
public_key  = key_pair.public_key
private_key = key_pair.private_key
logger.info("Keys ready.")

# Vote Storage 
used_tokens = set()   # Prevents double voting — (security tests)
vote_tally  = {}      # Counts votes per candidate for the results route


# -------------------------------------------------------------------
# ROUTE 1 — GET /public-key
# Frontend calls this first so it can blind the message
# -------------------------------------------------------------------
@app.route('/public-key', methods=['GET'])
def get_public_key():
    pem = export_public_key_pem(key_pair)
    return jsonify({
        "public_key" : pem,       
        "pem"        : pem,        
        "n"          : str(public_key.n),
        "e"          : str(public_key.e),
        "bits"       : public_key.key_size
    })


# ROUTE 1.5 — POST /blind
@app.route('/blind', methods=['POST'])
def blind():
    try:
        data = request.get_json()
        message = data['message'].encode()

        from crypto.crypto import blind_message

        bm = blind_message(message, public_key)

        return jsonify({
            "blinded": str(bm.blinded),
            "r": str(bm.blinding_factor),
            "hash": str(bm.message_hash)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
# -------------------------------------------------------------------
# ROUTE 2 — POST /sign
# Server signs a blinded message (never sees the real vote)
# -------------------------------------------------------------------
@app.route('/sign', methods=['POST'])
def sign():
    try:
        data        = request.get_json()
        blinded_msg = int(data['blinded_message'])

        signed = sign_blinded(blinded_msg, private_key)

        logger.info("Blinded message signed. Server did not see original.")
        return jsonify({
            "blind_signature": str(signed)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


# ROUTE 2.5 — POST /unblind
@app.route('/unblind', methods=['POST'])
def unblind():
    try:
        data = request.get_json()

        blind_sig = int(data['blind_signature'])
        r         = int(data['r'])
        message_hash = int(data['hash'])

        from crypto.crypto import unblind_signature, BlindedMessage

        bm = BlindedMessage(
            blinded=0,
            blinding_factor=r,
            message_hash=message_hash
        )

        sig = unblind_signature(blind_sig, bm, public_key)

        return jsonify({
            "signature": str(sig)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
# -------------------------------------------------------------------
# ROUTE 3 — POST /verify
# Just checks if a signature is valid (does NOT record a vote)
# -------------------------------------------------------------------
@app.route('/verify', methods=['POST'])
def verify():
    try:
        data      = request.get_json()
        message   = data['message'].encode()
        signature = int(data['signature'])

        is_valid = verify_signature(message, signature, public_key)

        return jsonify({
            "valid"  : is_valid,
            "result" : "Signature is valid" if is_valid else "Signature is INVALID"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


# -------------------------------------------------------------------
# ROUTE 4 — POST /submit-vote
# Verifies signature AND records vote AND blocks double voting
# This is the main e-voting endpoint
# -------------------------------------------------------------------
@app.route('/submit-vote', methods=['POST'])
def submit_vote():
    try:
        data      = request.get_json()
        msg_str   = data['message']
        message   = msg_str.encode()
        signature = int(data['signature'])

        # Input validation
        if not msg_str.startswith("vote:"):
            return jsonify({
                "valid" : False,
                "error" : "Invalid vote format — message must start with 'vote:'"
            }), 400

        # Security Check 1: Duplicate vote prevention
        token_id = str(signature)       
        if token_id in used_tokens:
            logger.warning("DOUBLE VOTE ATTEMPT blocked.")
            return jsonify({
                "valid" : False,
                "error" : "Vote already submitted — duplicate token detected"
            }), 400

        # Security Check 2: Verify signature
        is_valid = verify_signature(message, signature, key_pair.public_key)
        if not is_valid:
            logger.warning("Invalid signature — vote rejected.")
            return jsonify({
                "valid" : False,
                "error" : "Invalid signature — vote rejected"
            }), 400

        # Record the vote
        used_tokens.add(token_id)
        # candidate = msg_str.replace("vote:", "")
        parts     = msg_str.split(":")
        candidate = parts[1] if len(parts) > 1 else msg_str
        vote_tally[candidate] = vote_tally.get(candidate, 0) + 1

        logger.info(f"Vote recorded for: {candidate}")
        return jsonify({
            "valid"     : True,
            "result"    : "Vote accepted and recorded",
            "voted_for" : candidate
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 400


# -------------------------------------------------------------------
# ROUTE 5 — GET /results
# Live vote tally (for demo)
# -------------------------------------------------------------------
@app.route('/results', methods=['GET'])
def results():
    return jsonify({
        "tally"       : vote_tally,
        "total_votes" : sum(vote_tally.values())
    })


# -------------------------------------------------------------------
# Run Server
# -------------------------------------------------------------------
if __name__ == '__main__':
    app.run(debug=True, port=5000)