"""
test_backend.py — Full Integration Test for Member 2's Backend

Member 2 

Tests the complete blind signature e-voting flow by calling the Flask API exactly as frontend would.

Run:
    # Terminal 1 — start the server
    python backend/app.py

    # Terminal 2 — run tests
    python backend/test_backend.py
"""

import sys
import os
import requests

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from crypto.crypto import blind_message, unblind_signature, import_public_key_pem

BASE = "http://localhost:5000"

def test_get_public_key():
    res = requests.get(f"{BASE}/public-key")
    assert res.status_code == 200

    data = res.json()
    assert "pem"  in data         
    assert "n"    in data
    assert "e"    in data
    assert int(data["e"]) == 65537

    print("test_get_public_key passed")
    return data


def test_full_vote_flow():
    """
    Full blind signature protocol:
        1. Get public key from server
        2. Blind the vote locally
        3. Send to server for signing
        4. Unblind locally
        5. Submit vote to server
        6. Verify vote was counted
    """
    # Step 1: Get server's public key
    key_data = requests.get(f"{BASE}/public-key").json()
    pub_key  = import_public_key_pem(key_data["pem"])

    # Step 2: Voter blinds their vote locally (frontend does this)
    vote    = b"vote:candidate_alice"
    blinded = blind_message(vote, pub_key)

    # Step 3: Send blinded message to server for signing
    res = requests.post(f"{BASE}/sign", json={
        "blinded_message": str(blinded.blinded)
    })
    assert res.status_code == 200
    blind_sig = int(res.json()["blind_signature"])

    # Step 4: Voter unblinds locally (frontend does this)
    real_sig = unblind_signature(blind_sig, blinded, pub_key)

    # Step 5: Submit the real vote + unblinded signature
    res = requests.post(f"{BASE}/submit-vote", json={
        "message"   : "vote:candidate_alice",
        "signature" : str(real_sig)
    })
    assert res.status_code == 200
    assert res.json()["valid"] == True

    print("test_full_vote_flow passed")
    return real_sig, "vote:candidate_alice"


def test_double_vote_blocked(real_sig, message):
    """
    Submitting the same token twice must be rejected.
    This is the replay / double-vote attack that Member 4 will test.
    """
    res = requests.post(f"{BASE}/submit-vote", json={
        "message"   : message,
        "signature" : str(real_sig)
    })
    assert res.status_code == 400
    assert res.json()["valid"] == False
    assert "duplicate" in res.json()["error"].lower()

    print("test_double_vote_blocked passed  ← replay attack BLOCKED")


def test_forged_signature_rejected():
    """
    A random integer as signature must be rejected.
    Models attacker who doesn't have the private key.
    """
    res = requests.post(f"{BASE}/submit-vote", json={
        "message"   : "vote:candidate_bob",
        "signature" : "123456789"
    })
    assert res.status_code == 400
    assert res.json()["valid"] == False

    print("test_forged_signature_rejected passed  ← forgery attack BLOCKED")


def test_tampered_message_rejected():
    """
    Signature obtained for message A must not work for message B.
    """
    key_data = requests.get(f"{BASE}/public-key").json()
    pub_key  = import_public_key_pem(key_data["pem"])

    # Get a valid signature for alice
    vote    = b"vote:candidate_alice"
    blinded = blind_message(vote, pub_key)
    res     = requests.post(f"{BASE}/sign", json={"blinded_message": str(blinded.blinded)})
    blind_sig = int(res.json()["blind_signature"])
    real_sig  = unblind_signature(blind_sig, blinded, pub_key)

    # Try to use alice's signature for bob
    res = requests.post(f"{BASE}/verify", json={
        "message"   : "vote:candidate_bob",
        "signature" : str(real_sig)
    })
    assert res.json()["valid"] == False

    print("test_tampered_message_rejected passed  ← message substitution BLOCKED")


def test_multiple_voters():
    """
    Simulate 3 independent voters casting votes.
    Each vote includes a unique voter_id so tokens are distinct
    (in a real system, voter IDs or nonces ensure uniqueness).
    """
    import time
    key_data = requests.get(f"{BASE}/public-key").json()
    pub_key  = import_public_key_pem(key_data["pem"])

    # Each voter has a unique nonce so their tokens don't collide
    voters = [
        f"vote:candidate_alice:voter_{int(time.time()*1000)+1}",
        f"vote:candidate_bob:voter_{int(time.time()*1000)+2}",
        f"vote:candidate_alice:voter_{int(time.time()*1000)+3}",
    ]

    for i, vote_str in enumerate(voters):
        vote    = vote_str.encode()
        blinded = blind_message(vote, pub_key)
        res     = requests.post(f"{BASE}/sign", json={"blinded_message": str(blinded.blinded)})
        blind_sig = int(res.json()["blind_signature"])
        real_sig  = unblind_signature(blind_sig, blinded, pub_key)

        res = requests.post(f"{BASE}/submit-vote", json={
            "message"  : vote_str,
            "signature": str(real_sig)
        })
        assert res.json()["valid"] == True, f"Voter {i+1} failed: {res.json()}"

    print("test_multiple_voters passed  (3 voters, 3 valid votes)")


def test_results():
    """Final vote tally is returned correctly."""
    res = requests.get(f"{BASE}/results")
    assert res.status_code == 200
    data = res.json()
    print(f"test_results passed  — Tally: {data['tally']}  |  Total: {data['total_votes']}")


def run_all_tests():
    print("\n" + "═" * 60)
    print("  Backend API — Integration Test Suite")
    print("═" * 60)

    tests_run = 0
    tests_passed = 0

    def run(name, fn, *args):
        nonlocal tests_run, tests_passed
        tests_run += 1
        print(f"\n[TEST] {name}")
        try:
            result = fn(*args)
            tests_passed += 1
            return result
        except AssertionError as e:
            print(f"  FAILED: {e}")
        except Exception as e:
            print(f"  ERROR : {e}")
        return None

    run("GET /public-key", test_get_public_key)
    result = run("Full vote flow (blind → sign → unblind → submit)", test_full_vote_flow)

    if result:
        real_sig, message = result
        run("Double vote blocked (replay attack)", test_double_vote_blocked, real_sig, message)

    run("Forged signature rejected", test_forged_signature_rejected)
    run("Tampered message rejected", test_tampered_message_rejected)
    run("Multiple voters", test_multiple_voters)
    run("GET /results", test_results)

    print("\n" + "═" * 60)
    print(f"  Results: {tests_passed}/{tests_run} passed")
    print("═" * 60 + "\n")


if __name__ == "__main__":
    run_all_tests()