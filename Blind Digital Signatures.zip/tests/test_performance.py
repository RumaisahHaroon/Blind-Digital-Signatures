# test_performance.py
# Run this alongside app.py to get timing data
# python tests/test_performance.py
import sys
import os
import time
import requests

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from crypto.crypto import (
    generate_keys,
    blind_message,
    sign_blinded,
    unblind_signature,
    verify_signature,
    import_public_key_pem,
)

BASE = "http://localhost:5000"

def measure_crypto_operations():
    """Measure pure cryptographic operation times (no network)."""
    print("\n" + "═" * 50)
    print("  CRYPTO OPERATION TIMING (Local, No Network)")
    print("═" * 50)
    
    # Key generation
    start = time.perf_counter()
    kp = generate_keys(key_size=2048)
    key_gen_time = (time.perf_counter() - start) * 1000
    
    message = b"vote:candidate_alice"
    
    # Blinding
    start = time.perf_counter()
    bm = blind_message(message, kp.public_key)
    blind_time = (time.perf_counter() - start) * 1000
    
    # Signing
    start = time.perf_counter()
    blind_sig = sign_blinded(bm.blinded, kp.private_key)
    sign_time = (time.perf_counter() - start) * 1000
    
    # Unblinding
    start = time.perf_counter()
    sig = unblind_signature(blind_sig, bm, kp.public_key)
    unblind_time = (time.perf_counter() - start) * 1000
    
    # Verification
    start = time.perf_counter()
    verify_signature(message, sig, kp.public_key)
    verify_time = (time.perf_counter() - start) * 1000
    
    print(f"\nKey Generation:     {key_gen_time:.2f} ms  (one-time cost)")
    print(f"Blinding:          {blind_time:.2f} ms  (client-side)")
    print(f"Signing:           {sign_time:.2f} ms  (server-side)")
    print(f"Unblinding:        {unblind_time:.2f} ms  (client-side)")
    print(f"Verification:      {verify_time:.2f} ms  (any party)")
    print(f"\nFull Protocol:     {blind_time + sign_time + unblind_time + verify_time:.2f} ms")
    
    return {
        "key_gen": key_gen_time,
        "blind": blind_time,
        "sign": sign_time,
        "unblind": unblind_time,
        "verify": verify_time
    }


def measure_api_roundtrip():
    """Measure API endpoint response times (includes network + crypto)."""
    print("\n" + "═" * 50)
    print("  API ROUNDTRIP TIMING (Network + Crypto)")
    print("═" * 50)
    print("  (Server must be running on localhost:5000)")
    
    try:
        # GET /public-key
        start = time.perf_counter()
        res = requests.get(f"{BASE}/public-key")
        pubkey_time = (time.perf_counter() - start) * 1000
        assert res.status_code == 200
        key_data = res.json()
        pub_key = import_public_key_pem(key_data["pem"])
        
        # Prepare blinded message
        vote = b"vote:candidate_alice"
        bm = blind_message(vote, pub_key)
        
        # POST /sign
        start = time.perf_counter()
        res = requests.post(f"{BASE}/sign", json={
            "blinded_message": str(bm.blinded)
        })
        sign_api_time = (time.perf_counter() - start) * 1000
        assert res.status_code == 200
        blind_sig = int(res.json()["blind_signature"])
        
        # Unblind locally (no API call)
        sig = unblind_signature(blind_sig, bm, pub_key)
        
        # POST /submit-vote
        start = time.perf_counter()
        res = requests.post(f"{BASE}/submit-vote", json={
            "message": "vote:candidate_alice",
            "signature": str(sig)
        })
        submit_time = (time.perf_counter() - start) * 1000
        assert res.status_code == 200
        
        # GET /results
        start = time.perf_counter()
        res = requests.get(f"{BASE}/results")
        results_time = (time.perf_counter() - start) * 1000
        assert res.status_code == 200
        
        print(f"\nGET /public-key:        {pubkey_time:.2f} ms")
        print(f"POST /sign:             {sign_api_time:.2f} ms")
        print(f"POST /submit-vote:      {submit_time:.2f} ms")
        print(f"GET /results:           {results_time:.2f} ms")
        print(f"\nTotal API Roundtrip:    {pubkey_time + sign_api_time + submit_time + results_time:.2f} ms")
        
        return {
            "pubkey": pubkey_time,
            "sign_api": sign_api_time,
            "submit": submit_time,
            "results": results_time
        }
        
    except requests.exceptions.ConnectionError:
        print("\n  ERROR: Server not running. Start with: python backend/app.py")
        return None


def measure_throughput():
    """Estimate how many votes per second the system can process."""
    print("\n" + "═" * 50)
    print("  THROUGHPUT ESTIMATE")
    print("═" * 50)
    
    kp = generate_keys(key_size=2048)
    message = b"vote:candidate_alice"
    
    # Measure 100 full protocol executions
    iterations = 100
    start = time.perf_counter()
    for _ in range(iterations):
        bm = blind_message(message, kp.public_key)
        blind_sig = sign_blinded(bm.blinded, kp.private_key)
        sig = unblind_signature(blind_sig, bm, kp.public_key)
        verify_signature(message, sig, kp.public_key)
    elapsed = (time.perf_counter() - start) * 1000
    
    avg_per_vote = elapsed / iterations
    votes_per_second = 1000 / avg_per_vote
    
    print(f"\n{iterations} votes processed in {elapsed:.2f} ms")
    print(f"Average per vote:       {avg_per_vote:.2f} ms")
    print(f"Estimated throughput:   {votes_per_second:.1f} votes/second")
    
    return {"avg_ms": avg_per_vote, "votes_per_sec": votes_per_second}


if __name__ == "__main__":
    print("\n" + "═" * 50)
    print("  PERFORMANCE EVALUATION")
    print("  Blind Signature E-Voting System")
    print("═" * 50)
    
    # Run all measurements
    crypto_times = measure_crypto_operations()
    api_times = measure_api_roundtrip()
    throughput = measure_throughput()
    
   