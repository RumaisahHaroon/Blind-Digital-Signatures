"""
test_crypto.py — Full Test Suite for Chaum's Blind Signature Module

Member 1
Tests cover:
  - Normal RSA signature correctness
  - Full blind → sign → unblind → verify protocol
  - Blindness property (signer cannot see original)
  - Unforgeability (tampered messages fail verification)
  - Edge cases and error handling
  - PEM key export/import for inter-module compatibility
"""

import sys
import os
import secrets
import hashlib

# Allow running from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from crypto.crypto import (
    generate_keys,
    blind_message,
    sign_blinded,
    unblind_signature,
    verify_signature,
    demonstrate_blindness,
    export_public_key_pem,
    import_public_key_pem,
    _hash_message,
)

# Use 1024-bit keys for test speed; use 2048 in production
TEST_KEY_SIZE = 1024

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures (shared across tests)
# ─────────────────────────────────────────────────────────────────────────────

def get_keys():
    """Generate a fresh key pair for testing."""
    return generate_keys(key_size=TEST_KEY_SIZE)


# ─────────────────────────────────────────────────────────────────────────────
# Test 1: Key Generation
# ─────────────────────────────────────────────────────────────────────────────

def test_key_generation():
    """Keys are generated with correct structure and sizes."""
    kp = get_keys()

    assert kp.public_key.e == 65537, "Public exponent should be 65537 (F4)"
    assert kp.public_key.n == kp.private_key.n, "Moduli must match"
    assert kp.public_key.n.bit_length() >= TEST_KEY_SIZE - 1, "Modulus too small"
    assert kp.private_key.d != kp.public_key.e, "d must differ from e"
    assert kp.private_key.p * kp.private_key.q == kp.private_key.n, "p*q must equal n"

    print("test_key_generation passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 2: Normal (Non-Blind) RSA Signature
# ─────────────────────────────────────────────────────────────────────────────

def test_normal_rsa_signature():
    """
    Direct RSA sign & verify without blinding.
    Validates that the raw RSA operations work correctly
    before adding the blinding layer.
    """
    kp = get_keys()
    message = b"vote:candidate_alice"

    m_hash = _hash_message(message) % kp.public_key.n

    # Sign directly (no blinding)
    signature = pow(m_hash, kp.private_key.d, kp.private_key.n)

    # Verify
    recovered = pow(signature, kp.public_key.e, kp.public_key.n)
    assert recovered == m_hash, "Normal RSA verify failed"

    print("test_normal_rsa_signature passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 3: Full Blind Signature Protocol
# ─────────────────────────────────────────────────────────────────────────────

def test_blind_sign_unblind_verify():
    """
    Core protocol test: Blind → Sign → Unblind → Verify.
    This is the most important test — the full Chaum protocol must work end-to-end.
    """
    kp = get_keys()
    message = b"vote:candidate_bob"

    # Step 1: Voter blinds the message
    blinded_msg = blind_message(message, kp.public_key)
    assert blinded_msg.blinded != blinded_msg.message_hash, \
        "Blinded value should differ from hash"

    # Step 2: Authority signs the blinded message
    blind_sig = sign_blinded(blinded_msg.blinded, kp.private_key)
    assert blind_sig > 0, "Blind signature must be positive"

    # Step 3: Voter unblinds the signature
    signature = unblind_signature(blind_sig, blinded_msg, kp.public_key)

    # Step 4: Anyone verifies the signature
    assert verify_signature(message, signature, kp.public_key), \
        "Verification of valid blind signature failed"

    print("test_blind_sign_unblind_verify passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 4: Blindness Property
# ─────────────────────────────────────────────────────────────────────────────

def test_blindness_property():
    """
    The signer never sees the original message.

    We verify that:
    (a) The blinded value is NOT equal to the message hash.
    (b) Blinding the same message twice produces DIFFERENT blinded values
        (because r is random each time), so the signer cannot correlate
        two blind signatures to the same voter choice.
    """
    kp = get_keys()
    message = b"vote:candidate_alice"

    blind1 = blind_message(message, kp.public_key)
    blind2 = blind_message(message, kp.public_key)

    # Same message → different blinded values (different r each time)
    assert blind1.blinded != blind2.blinded, \
        "BLINDNESS VIOLATED: Same message produced identical blinded values"

    # Different blinding factors each time
    assert blind1.blinding_factor != blind2.blinding_factor, \
        "Blinding factors should differ between calls"

    # Blinded value is not plaintext message hash
    m_hash = _hash_message(message) % kp.public_key.n
    assert blind1.blinded != m_hash, \
        "BLINDNESS VIOLATED: Blinded value equals message hash (no blinding applied)"

    print("test_blindness_property passed")


def test_signer_cannot_see_original():
    """
    Demonstrate that the signer only ever sees the blinded value,
    and it reveals nothing about the message without r.
    """
    kp = get_keys()

    votes = [b"vote:alice", b"vote:bob", b"vote:charlie"]
    blinded_values = set()

    for vote in votes:
        bm = blind_message(vote, kp.public_key)
        blinded_values.add(bm.blinded)

    # All blinded values are distinct (with overwhelming probability)
    assert len(blinded_values) == len(votes), \
        "Blinded values should be unique per message"

    # The signer receives only these integers — without r, they're indistinguishable
    # from random elements of Z_n* (this is the informal blindness argument)
    print("test_signer_cannot_see_original passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 5: Tampered Message Fails Verification
# ─────────────────────────────────────────────────────────────────────────────

def test_tampered_message_rejected():
    """
    A signature obtained for message A must NOT verify for message B.
    Ensures vote integrity — no message substitution allowed.
    """
    kp = get_keys()
    original = b"vote:candidate_alice"
    tampered = b"vote:candidate_bob"

    bm = blind_message(original, kp.public_key)
    blind_sig = sign_blinded(bm.blinded, kp.private_key)
    signature = unblind_signature(blind_sig, bm, kp.public_key)

    # Signature is valid for original
    assert verify_signature(original, signature, kp.public_key), \
        "Valid signature should verify"

    # Signature must NOT be valid for tampered message
    assert not verify_signature(tampered, signature, kp.public_key), \
        "INTEGRITY VIOLATED: Tampered message accepted with original signature"

    print("test_tampered_message_rejected passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 6: Forged Signature Rejected
# ─────────────────────────────────────────────────────────────────────────────

def test_forged_signature_rejected():
    """
    A randomly generated integer should not verify as a valid signature.
    Models an attacker who doesn't have the private key.
    """
    kp = get_keys()
    message = b"vote:candidate_alice"

    # Random forgery attempt
    forged_sig = secrets.randbelow(kp.public_key.n)

    assert not verify_signature(message, forged_sig, kp.public_key), \
        "UNFORGEABILITY VIOLATED: Random forgery passed verification"

    print("test_forged_signature_rejected passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 7: Wrong Key Fails Verification
# ─────────────────────────────────────────────────────────────────────────────

def test_wrong_key_rejected():
    """
    A signature from key pair A must not verify under key pair B.
    """
    kp1 = get_keys()
    kp2 = get_keys()
    message = b"vote:candidate_alice"

    bm = blind_message(message, kp1.public_key)
    blind_sig = sign_blinded(bm.blinded, kp1.private_key)
    signature = unblind_signature(blind_sig, bm, kp1.public_key)

    # Should verify with kp1
    assert verify_signature(message, signature, kp1.public_key), \
        "Valid signature should verify with its own public key"

    # Should NOT verify with kp2
    assert not verify_signature(message, signature, kp2.public_key), \
        "Signature from key1 should not verify with key2"

    print("test_wrong_key_rejected passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 8: Multiple Independent Votes
# ─────────────────────────────────────────────────────────────────────────────

def test_multiple_votes():
    """
    Simulate multiple voters casting votes independently.
    Each vote is independently blindable and verifiable.
    """
    kp = get_keys()
    votes = [
        b"vote:alice",
        b"vote:bob",
        b"vote:alice",
        b"vote:charlie",
        b"vote:bob",
    ]

    for i, vote in enumerate(votes):
        bm = blind_message(vote, kp.public_key)
        blind_sig = sign_blinded(bm.blinded, kp.private_key)
        signature = unblind_signature(blind_sig, bm, kp.public_key)
        assert verify_signature(vote, signature, kp.public_key), \
            f"Vote {i} failed verification"

    print(f"test_multiple_votes passed ({len(votes)} votes verified)")


# ─────────────────────────────────────────────────────────────────────────────
# Test 9: PEM Export / Import
# ─────────────────────────────────────────────────────────────────────────────

def test_pem_export_import():
    """
    Public key can be exported to PEM and re-imported.
    Required for sharing public key with other project modules (Members 2, 3).
    """
    kp = get_keys()
    pem = export_public_key_pem(kp)

    assert "BEGIN PUBLIC KEY" in pem or "BEGIN RSA PUBLIC KEY" in pem, \
        "PEM export malformed"

    # Re-import and use for verification
    imported_pk = import_public_key_pem(pem)
    assert imported_pk.e == kp.public_key.e
    assert imported_pk.n == kp.public_key.n

    # Verify a signature using the imported key
    message = b"test_pem_roundtrip"
    bm = blind_message(message, kp.public_key)
    blind_sig = sign_blinded(bm.blinded, kp.private_key)
    signature = unblind_signature(blind_sig, bm, kp.public_key)

    assert verify_signature(message, signature, imported_pk), \
        "Verification with imported PEM key failed"

    print("test_pem_export_import passed")


# ─────────────────────────────────────────────────────────────────────────────
# Test 10: Demonstrate Blindness (Integration Demo)
# ─────────────────────────────────────────────────────────────────────────────

def test_demonstrate_blindness():
    """
    Runs the blindness demonstration function used in class presentation.
    """
    kp = get_keys()
    message = b"vote:candidate_alice"

    result = demonstrate_blindness(message, kp.public_key, kp.private_key)

    assert result["signer_can_see_original"] == False
    assert result["signer_can_deduce_original"] == False
    assert result["verification_passes"] == True

    print("test_demonstrate_blindness passed")
    print(f"     Original msg      : {result['original_message']}")
    print(f"     Hash of message   : {result['message_hash'][:20]}...")
    print(f"     Blinded (signer sees): {result['blinded_value_seen_by_signer'][:20]}...")
    print(f"     Final signature   : {result['final_signature'][:20]}...")


# ─────────────────────────────────────────────────────────────────────────────
# Test Runner
# ─────────────────────────────────────────────────────────────────────────────

def run_all_tests():
    tests = [
        ("Key Generation",                  test_key_generation),
        ("Normal RSA Signature",            test_normal_rsa_signature),
        ("Full Blind Protocol",             test_blind_sign_unblind_verify),
        ("Blindness Property",              test_blindness_property),
        ("Signer Cannot See Original",      test_signer_cannot_see_original),
        ("Tampered Message Rejected",       test_tampered_message_rejected),
        ("Forged Signature Rejected",       test_forged_signature_rejected),
        ("Wrong Key Rejected",              test_wrong_key_rejected),
        ("Multiple Votes",                  test_multiple_votes),
        ("PEM Export/Import",               test_pem_export_import),
        ("Blindness Demonstration",         test_demonstrate_blindness),
    ]

    print("\n" + "═" * 60)
    print("  Chaum's Blind Signature — Test Suite")
    print("  Member 1 | InfoSec Project")
    print("═" * 60)

    passed = 0
    failed = 0

    for name, fn in tests:
        print(f"\n[TEST] {name}")
        try:
            fn()
            passed += 1
        except AssertionError as e:
            print(f"FAILED: {e}")
            failed += 1
        except Exception as e:
            print(f"ERROR : {e}")
            failed += 1

    print("\n" + "═" * 60)
    print(f"  Results: {passed}/{len(tests)} passed | {failed} failed")
    print("═" * 60 + "\n")

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)